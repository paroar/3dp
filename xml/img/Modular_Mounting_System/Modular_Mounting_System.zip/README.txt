                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2194278
Modular Mounting System by yyh1002 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This project is a mounting system for phones and lightweight cameras.

FEATURES:
- It is designed to be modular to provide flexible use. The system has potential to mount most phones and small cameras onto a wide range of objects. Using same parts printed for different purpose is the major approach. 
- The included phone clamp can grab phones very firmly. And it is suitable for phones from about 55mm wide to 80mm wide (iPhone 4 - iPhone 7 Plus and bigger). The clamp hook was angled 45 degrees so it won't be able to reach and accidentally press the buttons on the side of phone. 
- The modules can be used with GoPro compatible equipment. The bolts and nuts included in the design are standard M5. You can either print them or use metal ones for better stiffness. 
- With this modular system, I will be developing new add-ons to it. Feel free to watch this thing. Many of the objects designed for GoPro are already usable for this setup. I uploaded some STEP files for modular parts so everyone can also collaborate for better solutions. 

ACHIEVED APPLICATIONS:
- Phone/Camera/GoPro mount for Ultimaker 2 monitoring.
- Phone/Camera/GoPro mount for Aluminum extrusion printers.
- Desk clamp for phone/camera (get the bolt from original author page).
- Stand for phone/camera.
- Headphone stand.
- Bike mount for phone (in remixes)
- And much more applications in REMIX section

MAKING:
- In order for the bolts to be strong enough to take pulling force, they cannot be printed vertically. Therefore the bolts are oriented horizontally, with the bottom teeth trimmed off, and with 30 degrees step shape (it is usually 45 if printed vertical). With such treatment the bolts are both strong and easy to print with support material even at 0.2mm layer height. 
- Print bolts and nuts at low outer wall speed (15mm/s) to increase accuracy. If the tolerence for bolts and nuts doesn't workout for you, try change XY compensation setting in slicer to get a larger tolerance. I've also attached the settings used to create them so you could make your own with slightly altered values.
- Make sure you use metal bolts and nuts for mounting heavy items like camera.
- It is highly recommended to print with complete support interface for the parts in this project. Support interface would give a flat bottom which result in a better mechanical performance. 
- The orientation of stl files are already thought through during my testing. Try printing at the current orientation unless you run into problems. It is not recommended to reorient the arms to save support material. The tabs will be easy to break if printed otherwise. 
- Mirror the arm one after another in order to have knobs on the same side. 

NOTES:
- It is not recommended to extend the arm too long. General filament is not strong enough to take that much lateral load at this size and the arm would be very wobbly. And the arms are optimized to stay still. If you wish to use this design as selfie stick or similar purpose, please be careful with the material strength and use at you own risk. 

ACKNOWLEDGEMENTS:
- The joints are inspired by GoPro design. 
- The foldable arm is inspired by "GoPro counter balance folding stick. by UltiArjan" (http://www.thingiverse.com/thing:433378).
- Bolts and nuts are created with the awesome customizer "NUT JOB | Nut, Bolt, Washer and Threaded Rod Factory by mike_mattala" (http://www.thingiverse.com/thing:193647).
- The desk clamp is inspired by "G-Clamp fully printable by johann517" (http://www.thingiverse.com/thing:1673030). 
Thank you all for your great work so that I could accomplish this project. 

# Useful Parts

MOUNT BASES:
- Tripod style base, good for small printers: https://www.thingiverse.com/thing:2767323
- Car vent: https://www.thingiverse.com/thing:2986184
- Zip tie bike mount: https://www.thingiverse.com/thing:2266715
- Bolted bike mount: https://www.thingiverse.com/thing:2909355
- CR10: https://www.thingiverse.com/thing:2753828
- Taz-6: https://www.thingiverse.com/thing:2750852
- Flashforge Finder: https://www.thingiverse.com/thing:2660921
- Mount phone clamp on tripod: https://www.thingiverse.com/thing:2790283
- Xbox One S controller: https://www.thingiverse.com/thing:2774549
- Xbox 360 wired controller: https://www.thingiverse.com/thing:2553504
- Xbox 360 wireless controller: https://www.thingiverse.com/thing:2794805
- Sony PS3 controller: https://www.thingiverse.com/thing:2733267

OBJECT MOUNT:
- Mini Fisheye lens: https://www.thingiverse.com/thing:2785451
- Raspberry Pi night vision camera: https://www.thingiverse.com/thing:2657307
- Raspberry Pi Zero W case and camera: https://www.thingiverse.com/thing:2504847
- Elongated iPad Mini mount: https://www.thingiverse.com/thing:2482559

OTHER TYPE OF JOINTS:
- 3 DOF axis changer: https://www.thingiverse.com/thing:2358873
- Ball joint: https://www.thingiverse.com/thing:2243294
- Prong Gender Adapters: https://www.thingiverse.com/thing:2949373

OTHER KNOBS:
- Long knob: https://www.thingiverse.com/thing:163883
- Short knob: https://www.thingiverse.com/thing:537647

# Parts Assembly List

This is the list to indicate which function of the mount the parts belong to. 
There is also a drawing made by willemjan for instruction: https://www.thingiverse.com/make:415832
________________________________________

MOUNTING BASE - the base to attach the mount to something:
- Clip UM2
- Clip 2020 profile
- G-clamp
- Flat stand

ARMS - the foldable arms and connectors:
- Axis change connector
- Arm v2 (anything)
- M5.0 Nut
- M5x25 D
- M5 knob short

PHONE CLAMP:
- Phone clamp down grab
- Phone clamp up NO tab
- Phone clamp up WITH tab
- Phone clamp holder
- M5x65 D
- M5.0 Nut
- M5 knob for phone
- M5 knob short

CAMERA MOUNT:
- Camera Mount
- Camera Screw

# Update History

- 22/03/17 - The phone clamp knob originally uploaded has issue of screw poping out of knob instead of knob pulling the clamp out. A new knob named "M5 knob for phone v2 tighter" with smaller hole is uploaded for the socket to firmly grab the bolt. "Phone clamp down nongrab" is an old backup version which the clamp doesn't pull out while unscrewing the knob.  
- 02/04/17 - More variation of arms. Added more tolerance to the arms. 
- 13/04/17 - A holder that grabs the phone clamp less tight. (Phone clamp holder v2)
- 20/04/17 - After a period of use, the printed bolts or nuts start to give up, especially the nuts, not able to lock the arms in place. They are more like a temporary solution. I would buy metal bolts to replace them. 
- 24/04/17 - New version of the knob for phone clamp. More convenient to twist. Smaller diameter. (M5 knob for phone v3)
- 26/04/17 - New version of the knob for the joints with smaller diameter. The long knob is no longer needed. (M5 knob short v3)
- 09/05/17 - Longer M5x65 bolt for wide phones larger than 5.5 inch. (M5x65_D)
- 18/05/17 - Mount for lightweight cameras. (Camera Mount & Camera Screw)
- 18/05/17 - Moved the position of the nut in phone clamp, making it extend 10mm longer with M5x65 bolt. (Phone clamp down v3)
- 18/05/17 - Slightly more tolerance to holes for bolt. Minor change. 
- 04/06/17 - New version of the knobs with better grip. (M5 knob short v4, M5 knob for phone v4)
- 31/08/17 - New C clamp with the same width as the arms, not requiring support. 
- 14/02/18 - 4mm thicker phone clamp for phones with case. (Phone_clamp_down_4mm_thicker, Phone_clamp_up_4mm_thicker)
- 25/04/18 - Headphone stand attachment. (headphone holder.stl)