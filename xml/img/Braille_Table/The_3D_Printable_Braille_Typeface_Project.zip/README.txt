                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2861973
The 3D Printable Braille Typeface Project by aaskedall is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

After seeing some typefaces designed with Braille in mind I decided to take it on to try and create a new one that extrudes a custom 2d typeface with braille embedded on top. I created the letter forms in Adobe illustrator then imported svgs in blender to extrude and shape. 

These are currently sized in accordance with <a href="http://www.brailleauthority.org/sizespacingofbraille/sizespacingofbraille.pdf
" title="this documenation">
this documenation</a>. They can be scaled larger or smaller for whatever needs may arise.    


This piece is heavily influenced and inspired by <a href="http://brailleneue.com/" title="Kosuke Takahashi's incredible braille Neue project">
Kosuke Takahashi's incredible braille Neue project</a> and other exploratory works that have come before. If there are any specific changes or applications/mistakes I've made please comment.


# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator+
Rafts: Doesn't Matter
Supports: No

# How I designed this

![Alt text](https://cdn.thingiverse.com/assets/7e/d2/49/9d/f9/initial-grid.png)

![Alt text](https://cdn.thingiverse.com/assets/18/4b/7a/51/0f/overlay.png)

![Alt text](https://cdn.thingiverse.com/assets/b2/43/6a/60/89/ideation.png)

![Alt text](https://cdn.thingiverse.com/assets/c1/f3/8e/68/7e/refine.png)