                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1643878
Subaru WRX EJ20 Boxer Engine Model - Fully Functioning by ericthepoolboy is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Cutaway version of the EJ20 can be found here.
https://www.thingiverse.com/thing:2451310

All my models are printed on a Prusa i3 kit. You can find the one I use by clicking the link below. You can get 15% off by using code "GBTE"
<a target="_blank" href="https://www.gearbest.com/3d-printers-3d-printer-kits/pp_624058.html?wid=1433363&lkid=14270088" title="Gearbest Tronxy Prusa I3">Tronxy Prusa I3</a>

Complete hardware kits are now available. I partnered with MakerRX. Head over to their page to purchase my kit and get 10% off HatchBox/ColorFabb Filament which is some of the best filament that you can get for the price.
https://www.makerrx.com/products/mrx2
Kits include all non printed parts, 500 rpm dc motor, speed controller, power connectors, and DC power supply. 

For international orders, click below
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="7D5FRDDTKA9RG">
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

Subaru EJ20 Boxer engine!!!

It's fully functional as in all parts move as intended in the real thing. Do not confuse it with a real engine, as this is not.

This engine is slightly harder to print and assemble than my Toyota 22RE engine. So it is best to print or familiarize yourself with my previous models if you choose to print this one. The scale is once again 35% of the original which seems to be a good size for printing and finding fasteners that work and look right. The tolerances are a little tighter and depending on your printer the crankshaft might take some tweaking to get it right so that there is not interference while rotating.

This model has smaller engine block than the Toyota 22RE which will allow smaller printers to print it.


https://youtu.be/6ibIXaNXtqQ

# Print Settings

Printer Brand: RepRap
Printer: Prusa i3
Rafts: Doesn't Matter
Supports: Doesn't Matter
Resolution: .2mm
Infill: 20-40%

Notes: 
Everything was printed on a $200 Chinese Prusa i3 kit. So any printer should be able to print this if it has a big enough build envelope.  You will need to make the decision if you want to use support or a raft. Some parts it's obvious that support will be needed. Others will need support depending on your machine. I did not need supports while printing the engine blocks but that may vary from machine to machine.

# How I Designed This

Everything was done in SolidWorks using only hand measuring tools. 
All parts turned intp STL files, scaled, and repaired using NetFab basic.