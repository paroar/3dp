                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2901274
Collapsible Basket (optimized)  by 3DPRINTINGWORLD is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Collapsible Basket Optimized for 3D printing

This basket prints in place as one part and doesn’t require any supports. It prints flat but folds it into a basket!

This is a remix of the first collapsing basket I designed, that version uses a wood cutting trick where you make a spiral cut on an angle and the flexibility of the material allows it to form the basket. The angle of the spiral cut interlocks the walls of the basket in one direction. 

It was cool how this can be accomplished with a saw and some wood but I have a 3D printer and some plastic so I thought I would use some of the advantages a 3D printer has to offer. I like the new version better because of the features I was able to add since I’m using a 3D printer, but they both use a different method of forming the basket which is pretty cool. 

Original Collapsible Basket: https://www.thingiverse.com/thing:2886975

The original version used an angled spiral cut to form the basket but this version instead uses interlocking individual cups. This is a big improvement as when you tip the original version upside down the basket would go all slinky and fall out, this version will stay flat. I incorporated a cam into the kick stand so that it tightens as it rotates making the basket more stable when standing. I added a catch to the basket and a detent to the kickstand to better keep them in place when the basket is folded flat. 

I also tried to remove as much extra material as possible.  This version is the same width and height as the original but uses a quarter of the plastic.

I designed the basket in Inches so you will have to scale the file up in your slicer 2540% to convert to metric.

Here is my Amazon Affiliate Link to the Hatchbox Gold PLA Filament I used to make the basket :
https://amzn.to/2DikMq3

My assistant demonstrates how easy it is to take a freshly printed basket off the printer and unfold it.
https://youtu.be/7OAqEXW8H-k


# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No

Notes: 
I designed it in inches so scale it up in your slicer 25.4 x's or 2540%.