                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3090603
Letter-Cryptex by Hiob is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

If you have problems with the dimensions and all will not fit good make this test and recalibrate your slicer:
https://www.thingiverse.com/thing:1622868

------------------------------------------------------------------------------------------------------------------------

If you download or collect one of my designs, please give me a like!

------------------------------------------------------------------------------------------------------------------------

Deutsch:

Hier handelt es sich um einen Remix von:
https://www.thingiverse.com/thing:3074829

Eine schöne Möglichkeit um z.B. Gutscheine, Geld oder Schriftrollen zu verpacken und zu verschenken!
Das Codewort ist frei einstellbar und jederzeit abänderbar!!!
Ich habe die Ursprungs-Vorlage etwas meinen Bedürfnissen angepasst und alles etwas gängiger gemacht!
Diese Version des Letter-Cryptex hat 10 Buchstaben (Version A)!

Bitte die Anleitung zum Zusammenbau unter "Post-Printing" beachten!

Weitere Versionen (z.B. 4 bis 15 Buchstaben), Abwandlungen, Modifikationen und sonstiges findest du hier:
https://www.thingiverse.com/thing:3151555

Hier ein passender Ständer zur Präsentation:
https://www.thingiverse.com/thing:3162531


Viel Spaß!

------------------------------------------------------------------------------------------------------------------------

English:

This is a remix of:
https://www.thingiverse.com/thing:3074829

A nice way to vouchers, money or scrolls to pack and give away!
The codeword is freely adjustable and can be changed at any time!!!
I adapted the origin template a bit to my needs and made everything a little more common!
This version of Letter-Cryptex has 10 letters (Version A)!

Please follow the instructions for assembly under "Post-Printing"!

Other versions (for example 4 to 15 letters), modifications, modifications and others can be found here:
https://www.thingiverse.com/thing:3151555

Here is a matching stand for presentation:
https://www.thingiverse.com/thing:3162531

Have fun!

------------------------------------------------------------------------------------------------------------------------


Annotation:

Apparently, some of you have problems with "Slic3r" in connection with Letter Cryptex! Apparently errors are displayed!
I can not help you because I do not use this program!
Allegedly, however, you can fix the error with a repair program!
Or just use another slicer (like Cura or S3D)! With Cura or S3D there are no problems, as you can already see through the many "makes"!
I am really sorry that I can not help in this special case with Slic3r! I do not have this program and I do not know it!

# Print Settings

Printer: Anycubic i3 MEGA
Rafts: No
Supports: No
Resolution: 0,2 mm
Infill: 20 %
Filament_brand: SUNLU
Filament_color: black
Filament_material: PLA +

Notes: 
Deutsch:

Für jeden Buchstaben-Ring (Letter_Ring) werden 3 Federn (Springs) benötigt! Bei dieser Version (10 Buchstaben) also 30 Federn!

Bemalt bzw. behandelt habe ich meine Ausdrucke ganz einfach mit Metalic-Wachs (Rub'n Buff bzw. mit Wax Paste von Pentart)... einfach etwas Wachs auf die Fingerspitze getan und vorsichtig auf dem Druck verrieben... die Effekte kommen von selbst!

Falls jemand eine tolle Idee für Zahlen, Symbole oder sonstiges Zubehör hat... einfach her damit... versuche es gerne umzusetzen... falls ich Zeit dafür habe!

------------------------------------------------------------------------------------------------------------------------

English:

For each Letter_Ring 3 springs are needed! In this version (10 letters) so 30 springs!

I simply painted or treated my prints with Metalic wax (Rub'n Buff or Penta wax paste) ... just put some wax on the fingertip and rub gently on the print ... the effects come from even!


If someone has a great idea for numbers, symbols or other accessories ... just let me try it ... if I have the time!


# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/fd/ba/20/bc/f8/IMG_2990.jpg)
Set the letter!

![Alt text](https://cdn.thingiverse.com/assets/88/59/ad/0e/63/IMG_2991.jpg)

![Alt text](https://cdn.thingiverse.com/assets/2f/b0/76/4c/1f/IMG_2992.jpg)
Use glue to connect both parts (Outer_Core and Left_Side)! I always use 2-K-glue! 

![Alt text](https://cdn.thingiverse.com/assets/96/5a/98/0a/de/IMG_2993.jpg)

![Alt text](https://cdn.thingiverse.com/assets/d1/4d/2d/96/d1/IMG_2994.jpg)
Carefully insert the three springs for the first ring!

![Alt text](https://cdn.thingiverse.com/assets/f2/e7/f3/f0/44/IMG_2995.jpg)

![Alt text](https://cdn.thingiverse.com/assets/8e/2f/c6/1f/a5/IMG_2996.jpg)
Slide the first ring over the three springs!

![Alt text](https://cdn.thingiverse.com/assets/d4/8b/23/4e/29/IMG_2997.jpg)

![Alt text](https://cdn.thingiverse.com/assets/a5/ca/a1/07/63/IMG_2998.jpg)
Now attach the next springs for the second ring!

![Alt text](https://cdn.thingiverse.com/assets/0c/cb/10/a1/ab/IMG_2999.jpg)
Slide on the second ring!

![Alt text](https://cdn.thingiverse.com/assets/e6/b8/c5/de/85/IMG_3001.jpg)
Now do this until all rings are attached!

![Alt text](https://cdn.thingiverse.com/assets/eb/be/36/ee/81/IMG_3002.jpg)
Finally, screw on the holder (retrainer) so that the rings can not come out!

![Alt text](https://cdn.thingiverse.com/assets/16/96/db/34/12/IMG_3003.jpg)
Push the inner core into the outer core!

![Alt text](https://cdn.thingiverse.com/assets/b1/4e/45/00/db/IMG_3004.jpg)
First, check if the rings can be turned!

![Alt text](https://cdn.thingiverse.com/assets/d2/3c/24/ec/bd/IMG_3005.jpg)
Now paste in the right side in the groove glue!

![Alt text](https://cdn.thingiverse.com/assets/98/c4/1f/03/c5/IMG_3006.jpg)
Carefully place the right side and let the glue dry!

![Alt text](https://cdn.thingiverse.com/assets/2a/1e/2f/05/56/IMG_3011.jpg)
If necessary, paint the letter-cryptex!