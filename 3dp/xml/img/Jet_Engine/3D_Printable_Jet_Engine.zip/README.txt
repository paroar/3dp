                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1327093
3D Printable Jet Engine by CATIAV5FTW is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

A model of a 2-spool high bypass turbofan. I designed the whole engine from scratch with visual cues to certain existing engines.  For example, I think Rolls-Royce makes the best-looking fans, so there's some resemblance there... By the way, this model was featured on [SolidSmack.](http://www.solidsmack.com/cad/model-of-the-week-3d-printable-high-bypass-jet-engine/)

Several parts benefit from the use of custom supports. I included these supports in the parts as needed, and they are much better than a slicer's default grid-like support structures. However, certain parts (fan stator casing, for example) also have typical overhangs that still require normal supports that you'll need to apply in your slicer. All parts with the custom supports have (With Supports) at the end of the file names. If you'd rather not use these custom supports, download instead the parts with (No Supports) at the end of the file names. 

The biggest parts were designed to maximize an 8x10x8 build volume. I uploaded cut-in-half versions of the biggest parts (fan casings and stand) so smaller printers can print this without scaling everything down. These parts are down at the bottom of the file list and have the word "cut" somewhere in the file names. 

Each part was designed with a specific printing orientation in mind (see "Individual Components with Orientations.zip" for pictures). Due to the concentric fit of many of the components, the order that parts are assembled is very important. I uploaded a diagram with labels to all parts for reference.

Due to popular demand, I uploaded unsectioned, full-revolution versions of parts that had sections cut away (casings and stators, mostly). These all contain the custom supports and are contained in "Unsectioned Parts With Supports.zip".  

I organized the file list to separate between parts with and without the custom supports. Please refer to the BOM (Bill of Materials, aka Parts List) for keeping track of what parts to print. 

======================================================================

I used some non-printed hardware, namely the fasteners (screws, washers, and nuts) and ball bearings. These are listed below with the links where I got each:

 - Metric machine screw, star drive pan head, stainless steel A-2, 2.5mm x 0.45mm (1 box of 100) https://www.boltdepot.com/Product-Details.aspx?product=19240

 - Metric flat washer, stainless steel A-2, 2.5mm (2 boxes of 100) https://www.boltdepot.com/Product-Details.aspx?product=7365

 - Metric hex nut, stainless steel A-2, 2.5mm x 0.45mm (1 box of 100) https://www.boltdepot.com/Product-Details.aspx?product=7363

 - 6204 open ball bearing 20x47x14 (quantity 2) http://www.amazon.com/6204-Bearing-20x47x14-Open-Bearings/dp/B00IK4MCC2/ref=sr_1_106?srs=3445389011&ie=UTF8&qid=1462587921&sr=8-106

 - 6003 open ball bearing 17x35x10 (quantity 2) https://www.amazon.com/6003-Bearing-Deep-Groove-Bearings/dp/B00FNU80CC

======================================================================

This was printed on a Makergear M2, **so the gaps and clearances that I designed in the model might not be optimal for your printer**!  If something is too tight or too loose, please notify me in the comments so that I can adjust them in my model and upload a revised file. Make sure your printer axes are as perpendicular as possible; otherwise, the engine will wobble and scrape as it spins.  

Good luck and happy printing!

Thanks Max for the yellow engine rendering!

# How I Designed This

Designed to minimize the need for supports as much as possible.