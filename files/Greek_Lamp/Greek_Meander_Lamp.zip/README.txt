                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3434805
Greek Meander Lamp by Hultis is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Lamp with Ancient Greek meander patterns. Somewhat easy print since it's printed flat, and scalable to fit smaller beds.

# Instructions

1. **Print.** Part1 and part2 should be printed solid and with 2 walls. More details on this below. If your first layer is good everything else will be smooth sailing, so you might want to print it at higher temperature and maybe a bit slower.
2. **Glue up.** Bend part1 and part2 and glue it all together. If some parts are hard to bend you can lightly score the bends with the back of a knife.
3. **Light it up.** Place an IKEA LEDBERG (ideally with the lens removed) in the middle of the bottom. Other lamps with a small exposed LED also work.

For more information I recommend checking out [this make](https://www.thingiverse.com/make:624834) which has tons of tips on printing and assembly.

# Printing & scaling

![Alt text](https://cdn.thingiverse.com/assets/49/02/8e/b9/9c/slicer.jpg)

When slicing, make sure that the part of the bottom layer that's going to be bent goes diagonally or perpendicularly as in the picture. You may need to experiment with wall count and line width. I used 2 walls at 0.5mm wide for the full sized version.

This model can be scaled to fit a ~200mm bed. Just scale normally and make sure that you still get a proper bottom layer. You may need to lower layer width slightly to get the correct bend as described above.