                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2829553
Easter Eggs by Antonin_Nosek is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Update: Hello guys! Now you can see all of the eggs printed by 3DMN on his youtube <3
https://www.youtube.com/watch?v=YSEwv664MSU

Hello Thingiverse!

Easter are near and I want to bring you something special!

Let me introduce you my beautiful easter eggs collection. All of them are easy to print, fixed, flatted and ready to slice! 

// FOR PRINT PROCESS TIPS LOOK DOWN TO NOTES //

I want to say thank you to amazing czech guys from Fillamentum, because their beautiful Vertigo Grey PLA gives them exclusive look! :) 
https://fillamentum.com

Enjoy my friends!


# Print Settings

Printer Brand: Prusa
Printer: i3 MK2S
Rafts: Doesn't Matter
Supports: Doesn't Matter
Resolution: 0.15
Infill: 20%

Notes: 
There is no universal cook book how to print all of my eggs, but I will tell you all of 
 importants.

All of the eggs have little plane on bottom. Brim is recomended!

Voronoi Eggs 
Set travel speed to 200 mm/s
Increase retraction (on Prusa Slic3r 1,2 mm) //default 0,8
turn off the Z lift
decrease the print temp about 5-10 C. I prefer temps about 200C for PLA
NO SUPPORTS needed

Minecraft Egg 
This one is only one which really need supports!

Other eggs
No special parameters! :) They are easy at all :) only one recomendation is the brim