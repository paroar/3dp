                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3327968
WE-R2.4 Six-Axis Robot Arm by LoboCNC is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This robot arm is (very) roughly styled as an 80% scaled version of the UR3 industrial robot.  It uses the same design philosophy of simply placing a motor/reducer actuator unit at each joint, with six actuators stacked up to make a 6-axis arm.  Now while the UR3 uses hollow torque motors coupled with harmonic drives ($$$) for the actuators, this robot uses the stepper motor/compound planetary actuators I posted here: https://www.thingiverse.com/thing:3293562.  Two of the large actuators get used for the first two base joints, one of the medium sized actuators gets used for the elbow joint, and three of the small ones get used for the wrist joints.  And the gripper* I've posted here: https://www.thingiverse.com/thing:3116728.

For the controller, I've used seven of Pololu's Tic T500 stepper controllers with custom firmware I wrote to support coordinated motion.  You can find the gory details, including a Windows test utility program, here: https://drive.google.com/open?id=1rKRuWC4jAOekrds_WGUC7DkwlVsk2zdb

This is very much a work in progress and I'll be filling in the holes as I get time.  In the meantime, please feel free to post questions in the comments section if you need details I haven't gotten to yet.  Please read through all of the material here and ask me any questions you have before starting to build this - it is *not* an easy weekend project!

https://youtu.be/7u_UjMB8tJI

And here is an excellent video posted by jlauer of his make of the arm:
https://www.youtube.com/watch?v=tEbJV32GyYU

And another by jlauer with the development of his custom controller board:
https://www.youtube.com/watch?v=RdmdFIhCo4M

*The gripper shown in the video is slightly different than the one posted.

# Print Settings

Printer Brand: MakerGear
Printer: MakerGear M2
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 25%
Filament_brand:  
Filament_material: PLA

Notes: 
All of these structural parts of the arm print up pretty easily without supports.  You will need one of each piece except for you'll need 3 wrist shell pieces, 3 wrist caps and 7 of the Tic bases.

Note: I've included a shorter version of the upper arm link for people with shorter printers.

# Post-Printing

## Purchased Parts

*Screws (approximate numbers)*
20 4-40 socket head 1/4" 
20 4-40 socket head x 3/8"
30 6-32 socket head x 3/8"
20 4-40 nuts
20 6-32 nuts
30 2-56 x 1/8" screws


*Motors*
These are recommended motors, but you may be able to find equivalent ones on ebay, etc:
Base Rotation:17HS15-1504S1 (OMC)
Shoulder Elevation: 17HS19-2004S1 (OMC)
Elbow: 17HS13-1334S (OMC)
Wrist + Gripper (4): 35PM048S8-08001 (Moon's)

*Controllers*
7 Pololu Tic T500 (programmed with custom firmware)
4ft 24ga, 2 twisted pair cable  (4 wires total)
100 Jameco 100766 female crimp pin
3/32" heatshrink tubing

*Misc. Hardware*
150 6mm dia. airsoft BB's

## Assembly

Start by printing an assembling the actuators (https://www.thingiverse.com/thing:3293562) - 2 of the large, 20 pitch actuators, 1 of the 30 pitch actuators, and 3 of the small 40 pitch actuators.  You will also need to tap the mounting holes on the back side of each reducer housing.  For the 20 and 30 pitch actuators, use a 6-32 tap, and for the 40 pitch actuator, use a 4-40 tap.

Assembly goes most easily from the base up. Start by assembling the base cone to the 20 pitch actuator with the medium length motor with 6-32 screws. Press four 6-32 nuts into the pockets in the bottom of the shoulder plate and then attach the shoulder plate to the top of the first actuator.  Next, screw the  shoulder shell to the shoulder plate.  To complete the shoulder, insert the second 20 pitch actuator (with the longest motor) into the shoulder shell.

For the elbow, first tap the  four 6-32 holes in the end of the upper arm and then attach the elbow shell.  Insert the 30 pitch actuator (with the shortest NEMA 17 motor) into the shell.  Then attach the upper arm to the face of the shoulder elevation actuator.

The wrist starts with tapping the four 4-40 holes in the end of the upper arm and then attaching one of the wrist shells.  Then insert one of the 40 pitch actuators into that shell.  Next, attach the second wrist shell to the face of that actuator and then insert another 40 pitch actuator.  Finally, add the last shell and actuator for the final joint.


## Wiring

Wiring is one of the trickiest issues to deal with when building a robot arm.  Unfortunately, these actuators do not have hollow centers like the fancy UR3 actuators, so cables have to jump around each joint with enough slack to allow for joint movement.  To minimize the wiring, a serial bus (V+, GND, TX, RX)  is used with small controller boards distributed up the arm, one board located at each motor.

Each controller board has a redundant set of V+, GND, TX and RX pins.  This makes it easy to use daisy-chain cables to go from one board to the next.  For V+ and GND, there is actually a second set of holes on the board for optional screw terminals, but I soldered in a second set of header pins.  For TX and RX, I co-opted the unused Step and Dir pins (you have to remove the two current limiting resistors to isolate these pins) and then I tacked a jumper wire between Dir and RX and between Step and TX.

When making your cables, you want to twist the RX with GND and the TX wire with V+ for noise immunity.  Because not all the pins for each cable end are together (and because there is not room for a connector housing in some of the joints), I simply crimped a female pin onto each wire and insulated with heat shrink tubing.  You then have to be very careful in connecting each wire individually to each pin.  (V+ pins are all connected together, GND pins are all connected together, TX from the host is connected together with all of the Tic RX pins and RX from the host is connected together with all of the Tic TX pins.

Note that before wiring the robot (and in fact, before assembly) you should layout all of your controllers and motors on the bench, wire them up and test everything with the test software.

Each Tic board should be mounted to one of the Tic base pieces.  For joints 1 and 3 (base rotation and elbow) you can mount each Tic base directly to the back of the motor with double-sided tape.  For the wrist joints, the Tic board & base will also sit on the end of the motor, but you'll need to pull the base off easily to disassemble the joint,  Therefore, you can just kind of cram it in place and put on the shell cap to hold it there.  On the base elevation joint, there's not enough room on the end of the motor, so after plugging in your wires, you can slide it in on the side of the motor.

I've included notches in each shell for cables to go in and out and also a small hole for anchoring a zip tie to hold the cables in place.  On the forearm and upper arm, you can snake the cables internally.

## Software and Testing

The standard  firmware for the Tic T500 boards from Pololu does not support multi-axis coordinated motion as required by an arm like this.  So I wrote my own firmware which you will need to program into the Tic controllers.  (You could use the standard firmware, but you won't be able to get very good synchronization of all of the arm joints.)  Unfortunately, you can't use Pololu's USB bootloader (they wouldn't give me access) so you have to program the on-board PIC18F25K50 chip directly using a PicKit programmer.  You can find all of the gory details of this firmware (source code, docs), and how to program your boards at:

https://drive.google.com/open?id=1rKRuWC4jAOekrds_WGUC7DkwlVsk2zdb

This directory also contains a Windows test program that can be used for testing individual joints and also (very crudely) execute simple sequences of robot motions.  The C++ source code for the test program is included.  I wrote this using an ancient version (v5.0) of C++ Builder, but there is a free, much more modern version of C++ Builder now available (Community Edition).

## Stuff still to do...

*Joint Limit Stops*
You'll notice that each actuator has a slot in the stationary rim.  This was designed in to hold a floating joint stop piece that also engages a slot on the mating part of the next joint for form a joint stop with greater a than 360 deg. range.  Rather than having to wire up limit switches everywhere, the plan is to run each joint against a hard stop for homing.  This floating stop pieces still need to be designed and tested.

*Modify the Gripper*
The gripper I posted originally uses a small DC motor, which I was planning on running from one channel of the Tic stepper driver.  Unfortunately, the motor brush noise plays havoc with the driver chip, so in the video, I used and earlier stepper driven gripper.  The stepper gripper is a little weak and needs some work.

*Robot Kinematics*
The test software I've go so far is pretty rudimentary and does not have any forward or reverse robot kinematics.  I need to add these functions to get Cartesian motion, or better get, get the whole arm up and running within ROS (an open source robot operating system).

*Real Documentation*
I need to write a real manual for printing, assembling, wiring and running this robot.