                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3096598
Chainmail - 3D Printable Fabric by FLOWALISTIK is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

I would love to keep sharing my projects with all of you. If you enjoy with my designs, I invite you to become a patron, you will get early access to my designs and exclusive content! Also, you can help with a small donation.

Patreon: http://www.patreon.com/flowalistik
Donations: http://www.paypal.me/flowalistik

---

3D Printable chainmail. 

The chainmail size is 195x195mm. A 60x60mm sample is available to test and find the right settings before printing the big chainmail. Print the model with a 0.4mm nozzle and 0% infill.

Download the dual/multi extrusion version here: 

https://www.thingiverse.com/thing:3096708

The source file is available. Open it with Autodesk Fusion 360 and create your own custom chainmail!

I'd like to thank all my supporters and patrons, with your help I've been able to create this project. The Patreon MVPs for this project are David Kessler, Damien, Keyboardbelle, 3D Maker Noob, 3D Printing Stuff, Filaments.directory, Remco Katz and Sabino!