                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3014536
Turboprop Engine by konchan77 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

This is a cutaway model of Turboprop Engine having following features for educational purpose.
Features are:
  (1) Centrifugal (Impeller type) compressor
  (2) Can type Combustion Chamber
  (3) Axial Flow Turbine
  (4) Reduction gears and propeller shaft 
  (5) Air inlet cowling with Oil Cooler Air Passage

Download files includes;
-files: STL Files
-images: STL File Figure and Index Picture for assembly Aid

Purchase Parts Information;
-Bearings 
   WBC6-12ZZ (6 x 12 x 4)   6ea - Assemble to outer holes of each Panel 
   F686ZZ(6 x 1 3x 5)   2ea - Assemble to center of each Panel
   689ZZ (9 x 17 x 5)   2ea - For LP and HP Impeller
   6900ZZ (10 x 22 x 6)  2ea - For Prop-Shaft, Turbine Shaft

-Aluminum Tubes 
   9mm dia x Appox. 70mm -  as Compressor Rotor Shaft (Make slots both ends)
   6mm dia x Appox. 100mm -  as Turbine to Compressor Coupling Shaft

-Screws
   Micro screws M1.4x3L -  Appox. 70 ea  - Direct screw-in to 1 mm dia hole (No nut), 
                                       Head side flange hole is 1.5 mm dia.
   Screws M2 x 20L -  1ea - M2 Tap is used - Starter associate parts
   Screws M2 x 10L -  Appox. 12ea - M2 Tap is used - Red. Gear Panels associate parts and IGV
   Screws M2 x 6L -  Appox. 4ea - M2 Tap is used - Diffusers and Turb. Shaft Coupling

Assembly Points
- Rotors, Gear Train Set and Casings can be assembled and adjusted separately. 
- Combustion Air Casing is slid to the outlet elbow assembly until aft end clears from the turbine case its bore at first. Then slide back to bore. Gluing is optional.
- Standard Skill (such as Drilling, Tapping, Filing, Tightening, Painting and Gluing etc) is needed and perseverance too.

Total Net Print Time: Approx. 50 HR
- (Estimated as case of PLA, 0.4mm Nozzle, 0.2mm Layer Height, 40% infill and No raft and support)
  Note: When at actual print, each parameter may be adjusted.

[Update] 2018.8.13
This is the original design for the followings. Please refer them.
- Mod Parts  :  https://www.thingiverse.com/thing:2416610
- Mod Parts2 : https://www.thingiverse.com/thing:2747907
- Mod Parts3 : https://www.thingiverse.com/thing:2792220
[Update]2018.8.22
Add "Assembly Charts" (pdf format) and figures are added to assist for assembly.
[Update] 2018.9.4
Parts List including Mod-Parts and Identification of rotaing parts.
[Update]20180913
Add the optional part "Reduction-Panel03f" for "Reduction-Panel03"
[Update]20181025
Add "Mount-Foot101" called in "Assembly Charts"

# Print Settings

Printer: idbox
Rafts: Doesn't Matter
Supports: Doesn't Matter
Resolution: depending on your experience
Infill: depending on your experience

# Post-Printing

## see above


# How I Designed This

## 123ddesign, fusion360